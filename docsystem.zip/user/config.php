<?php
ini_set("display_errors", 0);
$conn = mysqli_connect('localhost','root','','user_db');

?>